import { Request, Response } from 'express';
import * as fragranceController from '../controllers/fragranceController';
import Fragrance from '../models/Fragrance';
import '@types/jest'

// Mock the Fragrance model
jest.mock('../models/Fragrance');

describe('Fragrance Controller', () => {
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let responseObject = {};

  beforeEach(() => {
    mockRequest = {};
    mockResponse = {
      json: jest.fn().mockImplementation(result => {
        responseObject = result;
        return mockResponse;
      }),
      status: jest.fn().mockReturnThis(),
    };
  });

  describe('getAllFragrances', () => {
    it('should return all fragrances', async () => {
      const mockFragrances = [
        { name: 'Fragrance 1' },
        { name: 'Fragrance 2' },
      ];
      (Fragrance.find as jest.Mock).mockReturnValue({
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue(mockFragrances),
      });
      (Fragrance.countDocuments as jest.Mock).mockResolvedValue(2);

      await fragranceController.getAllFragrances(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.json).toHaveBeenCalledWith({
        fragrances: mockFragrances,
        totalPages: 1,
        currentPage: 1,
      });
    });

    it('should return a message when no fragrances are found', async () => {
      (Fragrance.find as jest.Mock).mockReturnValue({
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue([]),
      });

      await fragranceController.getAllFragrances(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.json).toHaveBeenCalledWith({ message: 'No fragrances found' });
    });
  });

  describe('getFragranceById', () => {
    it('should return a fragrance when found', async () => {
      const mockFragrance = { name: 'Test Fragrance' };
      mockRequest.params = { id: '123' };
      (Fragrance.findById as jest.Mock).mockReturnValue({
        lean: jest.fn().mockResolvedValue(mockFragrance),
      });

      await fragranceController.getFragranceById(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.json).toHaveBeenCalledWith(mockFragrance);
    });

    it('should return a message when fragrance is not found', async () => {
      mockRequest.params = { id: '123' };
      (Fragrance.findById as jest.Mock).mockReturnValue({
        lean: jest.fn().mockResolvedValue(null),
      });

      await fragranceController.getFragranceById(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.json).toHaveBeenCalledWith({ message: 'Fragrance not found' });
    });
  });

  describe('createNewFragrance', () => {
    it('should create a new fragrance', async () => {
      const newFragrance = { name: 'New Fragrance', description: 'Test', category: 'Test', image_url: 'test.jpg' };
      mockRequest.body = newFragrance;
      (Fragrance.findOne as jest.Mock).mockResolvedValue(null);
      (Fragrance.create as jest.Mock).mockResolvedValue(newFragrance);

      await fragranceController.createNewFragrance(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.status).toHaveBeenCalledWith(201);
      expect(mockResponse.json).toHaveBeenCalledWith({
        message: `New fragrance ${newFragrance.name} created`,
        fragrance: newFragrance,
      });
    });

    it('should return an error if required fields are missing', async () => {
      mockRequest.body = { name: 'New Fragrance' };

      await fragranceController.createNewFragrance(mockRequest as Request, mockResponse as Response, jest.fn());

      expect(mockResponse.status).toHaveBeenCalledWith(400);
      expect(mockResponse.json).toHaveBeenCalledWith({ message: 'All fields are required' });
    });
  });

  // Add more tests for updateFragrance and deleteFragrance methods
});